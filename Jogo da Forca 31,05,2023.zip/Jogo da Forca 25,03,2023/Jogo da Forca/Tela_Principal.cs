﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Jogo_da_Forca
{
    public partial class Tela_Principal : Form
    {

        string palavra = ""; // onde a palavra de teste, onde ira entrar a palavra do banco
        char[] resposta;

        public Tela_Principal()
        {
            InitializeComponent();
            //encherVetor();
        }

        private void SortearPalavra()
        {
            palavra = "PSICOFARMACOLOGIA";
            int contador = palavra.Length;
            resposta = new char[contador];
          
        }



        private void encherVetor()
        {
            for (int i = 0; i < 3; i++)
            {
                resposta[i] = '0';
            }
        }


        private void btn_Dica_Click(object sender, EventArgs e)
        {
            Cad_Palavra cadDica = new Cad_Palavra();
            this.Hide();
            cadDica.ShowDialog();
            this.Close();
        }

        private void gerarLetras(object sender, EventArgs e)
        {
  
            checarPalavra(sender as Button);
            
        }
        private void checarPalavra(Button botao)
        {
            txt_Palavra.Text = "";
            char[] palavra2 = palavra.ToCharArray();

            botao.Enabled = false;
            txt_Letras.Text += botao.Text; // coloca letra jogada sem repetir

            for (int i = 0; i < palavra.Length; i++)
            {
                if (palavra2[i] == Convert.ToChar(botao.Text) && resposta[i] == '\0')// quando alguma letra for igual ao botão pressionado e tiver algum campo vazio no vetor ele ira entrar
                {
                    resposta[i] += Convert.ToChar(botao.Text);//resposta recebe a letra do botão
                    txt_Palavra.Text += Convert.ToString(resposta[i]);// o campo de texto no jogo recebe a resposta
                }
                else
                {
                    if (resposta[i] == '\0')
                    {
                        txt_Palavra.Text += "_"; // mantem o campo que não foi descoberto ainda como *
                    }
                    else
                    {
                    }
                    
                    txt_Palavra.Text += Convert.ToString(resposta[i]);
                }
            }
        }

        private void btn_Iniciar_Click(object sender, EventArgs e)
        {
            SortearPalavra();
            liga_botao();
        }

        private void Tela_Principal_Load(object sender, EventArgs e)
        {
            desliga_botao();
        }
        private void desliga_botao()
        {
            btn_A.Enabled = false;
            btn_B.Enabled = false;
            btn_C.Enabled = false;
            btn_D.Enabled = false;
            btn_E.Enabled = false;
            btn_F.Enabled = false;
            btn_G.Enabled = false;
            btn_H.Enabled = false;
            btn_I.Enabled = false;
            btn_J.Enabled = false;
            btn_K.Enabled = false;
            btn_L.Enabled = false;
            btn_M.Enabled = false;
            btn_N.Enabled = false;
            btn_O.Enabled = false;
            btn_P.Enabled = false;
            btn_Q.Enabled = false;
            btn_R.Enabled = false;
            btn_S.Enabled = false;
            btn_T.Enabled = false;
            btn_U.Enabled = false;
            btn_V.Enabled = false;
            btn_W.Enabled = false;
            btn_X.Enabled = false;
            btn_Y.Enabled = false;
            btn_Z.Enabled = false;

            btn_Dica.Enabled = false;
        }
        private void liga_botao()
        {
            btn_A.Enabled = true;
            btn_B.Enabled = true;
            btn_C.Enabled = true;
            btn_D.Enabled = true;
            btn_E.Enabled = true;
            btn_F.Enabled = true;
            btn_G.Enabled = true;
            btn_H.Enabled = true;
            btn_I.Enabled = true;
            btn_J.Enabled = true;
            btn_K.Enabled = true;
            btn_L.Enabled = true;
            btn_M.Enabled = true;
            btn_N.Enabled = true;
            btn_O.Enabled = true;
            btn_P.Enabled = true;
            btn_Q.Enabled = true;
            btn_R.Enabled = true;
            btn_S.Enabled = true;
            btn_T.Enabled = true;
            btn_U.Enabled = true;
            btn_V.Enabled = true;
            btn_W.Enabled = true;
            btn_X.Enabled = true;
            btn_Y.Enabled = true;
            btn_Z.Enabled = true;

            btn_Dica.Enabled = true;
        }
        private void game_over()
        {
            if (true)
            {

            }
        }
    }
}
