﻿namespace Jogo_da_Forca
{
    partial class Tela_Principal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Tela_Principal));
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_Z = new System.Windows.Forms.Button();
            this.btn_Y = new System.Windows.Forms.Button();
            this.btn_W = new System.Windows.Forms.Button();
            this.btn_X = new System.Windows.Forms.Button();
            this.btn_V = new System.Windows.Forms.Button();
            this.btn_U = new System.Windows.Forms.Button();
            this.btn_T = new System.Windows.Forms.Button();
            this.btn_S = new System.Windows.Forms.Button();
            this.btn_R = new System.Windows.Forms.Button();
            this.btn_Q = new System.Windows.Forms.Button();
            this.btn_P = new System.Windows.Forms.Button();
            this.btn_O = new System.Windows.Forms.Button();
            this.btn_N = new System.Windows.Forms.Button();
            this.btn_M = new System.Windows.Forms.Button();
            this.btn_L = new System.Windows.Forms.Button();
            this.btn_J = new System.Windows.Forms.Button();
            this.btn_K = new System.Windows.Forms.Button();
            this.btn_I = new System.Windows.Forms.Button();
            this.btn_H = new System.Windows.Forms.Button();
            this.btn_G = new System.Windows.Forms.Button();
            this.btn_F = new System.Windows.Forms.Button();
            this.btn_E = new System.Windows.Forms.Button();
            this.btn_D = new System.Windows.Forms.Button();
            this.btn_C = new System.Windows.Forms.Button();
            this.btn_B = new System.Windows.Forms.Button();
            this.btn_A = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lb_erro = new System.Windows.Forms.Label();
            this.btn_Cadastrar = new System.Windows.Forms.Button();
            this.btn_Iniciar = new System.Windows.Forms.Button();
            this.btn_Dica = new System.Windows.Forms.Button();
            this.txt_Letras = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_Palavra = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.rb_Animais = new System.Windows.Forms.RadioButton();
            this.rb_cidades = new System.Windows.Forms.RadioButton();
            this.rb_Times = new System.Windows.Forms.RadioButton();
            this.rb_Objetos = new System.Windows.Forms.RadioButton();
            this.rb_Frutas = new System.Windows.Forms.RadioButton();
            this.rb_Carros = new System.Windows.Forms.RadioButton();
            this.label5 = new System.Windows.Forms.Label();
            this.rb_Facil = new System.Windows.Forms.RadioButton();
            this.rb_Medio = new System.Windows.Forms.RadioButton();
            this.rb_Dificil = new System.Windows.Forms.RadioButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lb_Chances = new System.Windows.Forms.Label();
            this.lb_barras = new System.Windows.Forms.Label();
            this.pbImagens = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagens)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.White;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.btn_Z);
            this.panel1.Controls.Add(this.btn_Y);
            this.panel1.Controls.Add(this.btn_W);
            this.panel1.Controls.Add(this.btn_X);
            this.panel1.Controls.Add(this.btn_V);
            this.panel1.Controls.Add(this.btn_U);
            this.panel1.Controls.Add(this.btn_T);
            this.panel1.Controls.Add(this.btn_S);
            this.panel1.Controls.Add(this.btn_R);
            this.panel1.Controls.Add(this.btn_Q);
            this.panel1.Controls.Add(this.btn_P);
            this.panel1.Controls.Add(this.btn_O);
            this.panel1.Controls.Add(this.btn_N);
            this.panel1.Controls.Add(this.btn_M);
            this.panel1.Controls.Add(this.btn_L);
            this.panel1.Controls.Add(this.btn_J);
            this.panel1.Controls.Add(this.btn_K);
            this.panel1.Controls.Add(this.btn_I);
            this.panel1.Controls.Add(this.btn_H);
            this.panel1.Controls.Add(this.btn_G);
            this.panel1.Controls.Add(this.btn_F);
            this.panel1.Controls.Add(this.btn_E);
            this.panel1.Controls.Add(this.btn_D);
            this.panel1.Controls.Add(this.btn_C);
            this.panel1.Controls.Add(this.btn_B);
            this.panel1.Controls.Add(this.btn_A);
            this.panel1.Location = new System.Drawing.Point(38, 33);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(512, 100);
            this.panel1.TabIndex = 1;
            // 
            // btn_Z
            // 
            this.btn_Z.BackColor = System.Drawing.Color.White;
            this.btn_Z.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Z.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Z.Location = new System.Drawing.Point(467, 53);
            this.btn_Z.Name = "btn_Z";
            this.btn_Z.Size = new System.Drawing.Size(32, 32);
            this.btn_Z.TabIndex = 25;
            this.btn_Z.Text = "Z";
            this.btn_Z.UseVisualStyleBackColor = false;
            this.btn_Z.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_Y
            // 
            this.btn_Y.BackColor = System.Drawing.Color.White;
            this.btn_Y.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Y.Location = new System.Drawing.Point(429, 53);
            this.btn_Y.Name = "btn_Y";
            this.btn_Y.Size = new System.Drawing.Size(32, 32);
            this.btn_Y.TabIndex = 24;
            this.btn_Y.Text = "Y";
            this.btn_Y.UseVisualStyleBackColor = false;
            this.btn_Y.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_W
            // 
            this.btn_W.BackColor = System.Drawing.Color.White;
            this.btn_W.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_W.Location = new System.Drawing.Point(353, 53);
            this.btn_W.Name = "btn_W";
            this.btn_W.Size = new System.Drawing.Size(32, 32);
            this.btn_W.TabIndex = 23;
            this.btn_W.Text = "W";
            this.btn_W.UseVisualStyleBackColor = false;
            this.btn_W.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_X
            // 
            this.btn_X.BackColor = System.Drawing.Color.White;
            this.btn_X.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_X.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_X.Location = new System.Drawing.Point(391, 53);
            this.btn_X.Name = "btn_X";
            this.btn_X.Size = new System.Drawing.Size(32, 32);
            this.btn_X.TabIndex = 22;
            this.btn_X.Text = "X";
            this.btn_X.UseVisualStyleBackColor = false;
            this.btn_X.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_V
            // 
            this.btn_V.BackColor = System.Drawing.Color.White;
            this.btn_V.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_V.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_V.Location = new System.Drawing.Point(315, 53);
            this.btn_V.Name = "btn_V";
            this.btn_V.Size = new System.Drawing.Size(32, 32);
            this.btn_V.TabIndex = 21;
            this.btn_V.Text = "V";
            this.btn_V.UseVisualStyleBackColor = false;
            this.btn_V.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_U
            // 
            this.btn_U.BackColor = System.Drawing.Color.White;
            this.btn_U.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_U.Location = new System.Drawing.Point(277, 53);
            this.btn_U.Name = "btn_U";
            this.btn_U.Size = new System.Drawing.Size(32, 32);
            this.btn_U.TabIndex = 20;
            this.btn_U.Text = "U";
            this.btn_U.UseVisualStyleBackColor = false;
            this.btn_U.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_T
            // 
            this.btn_T.BackColor = System.Drawing.Color.White;
            this.btn_T.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_T.Location = new System.Drawing.Point(239, 53);
            this.btn_T.Name = "btn_T";
            this.btn_T.Size = new System.Drawing.Size(32, 32);
            this.btn_T.TabIndex = 19;
            this.btn_T.Text = "T";
            this.btn_T.UseVisualStyleBackColor = false;
            this.btn_T.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_S
            // 
            this.btn_S.BackColor = System.Drawing.Color.White;
            this.btn_S.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_S.Location = new System.Drawing.Point(201, 53);
            this.btn_S.Name = "btn_S";
            this.btn_S.Size = new System.Drawing.Size(32, 32);
            this.btn_S.TabIndex = 18;
            this.btn_S.Text = "S";
            this.btn_S.UseVisualStyleBackColor = false;
            this.btn_S.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_R
            // 
            this.btn_R.BackColor = System.Drawing.Color.White;
            this.btn_R.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_R.Location = new System.Drawing.Point(163, 53);
            this.btn_R.Name = "btn_R";
            this.btn_R.Size = new System.Drawing.Size(32, 32);
            this.btn_R.TabIndex = 17;
            this.btn_R.Text = "R";
            this.btn_R.UseVisualStyleBackColor = false;
            this.btn_R.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_Q
            // 
            this.btn_Q.BackColor = System.Drawing.Color.White;
            this.btn_Q.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Q.Location = new System.Drawing.Point(125, 53);
            this.btn_Q.Name = "btn_Q";
            this.btn_Q.Size = new System.Drawing.Size(32, 32);
            this.btn_Q.TabIndex = 16;
            this.btn_Q.Text = "Q";
            this.btn_Q.UseVisualStyleBackColor = false;
            this.btn_Q.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_P
            // 
            this.btn_P.BackColor = System.Drawing.Color.White;
            this.btn_P.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_P.Location = new System.Drawing.Point(87, 53);
            this.btn_P.Name = "btn_P";
            this.btn_P.Size = new System.Drawing.Size(32, 32);
            this.btn_P.TabIndex = 15;
            this.btn_P.Text = "P";
            this.btn_P.UseVisualStyleBackColor = false;
            this.btn_P.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_O
            // 
            this.btn_O.BackColor = System.Drawing.Color.White;
            this.btn_O.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_O.Location = new System.Drawing.Point(49, 53);
            this.btn_O.Name = "btn_O";
            this.btn_O.Size = new System.Drawing.Size(32, 32);
            this.btn_O.TabIndex = 14;
            this.btn_O.Text = "O";
            this.btn_O.UseVisualStyleBackColor = false;
            this.btn_O.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_N
            // 
            this.btn_N.BackColor = System.Drawing.Color.White;
            this.btn_N.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_N.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_N.Location = new System.Drawing.Point(11, 53);
            this.btn_N.Name = "btn_N";
            this.btn_N.Size = new System.Drawing.Size(32, 32);
            this.btn_N.TabIndex = 13;
            this.btn_N.Text = "N";
            this.btn_N.UseVisualStyleBackColor = false;
            this.btn_N.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_M
            // 
            this.btn_M.BackColor = System.Drawing.Color.White;
            this.btn_M.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_M.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_M.Location = new System.Drawing.Point(467, 15);
            this.btn_M.Name = "btn_M";
            this.btn_M.Size = new System.Drawing.Size(32, 32);
            this.btn_M.TabIndex = 12;
            this.btn_M.Text = "M";
            this.btn_M.UseVisualStyleBackColor = false;
            this.btn_M.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_L
            // 
            this.btn_L.BackColor = System.Drawing.Color.White;
            this.btn_L.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_L.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_L.Location = new System.Drawing.Point(429, 15);
            this.btn_L.Name = "btn_L";
            this.btn_L.Size = new System.Drawing.Size(32, 32);
            this.btn_L.TabIndex = 11;
            this.btn_L.Text = "L";
            this.btn_L.UseVisualStyleBackColor = false;
            this.btn_L.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_J
            // 
            this.btn_J.BackColor = System.Drawing.Color.White;
            this.btn_J.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_J.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_J.Location = new System.Drawing.Point(353, 15);
            this.btn_J.Name = "btn_J";
            this.btn_J.Size = new System.Drawing.Size(32, 32);
            this.btn_J.TabIndex = 10;
            this.btn_J.Text = "J";
            this.btn_J.UseVisualStyleBackColor = false;
            this.btn_J.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_K
            // 
            this.btn_K.BackColor = System.Drawing.Color.White;
            this.btn_K.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_K.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_K.Location = new System.Drawing.Point(391, 15);
            this.btn_K.Name = "btn_K";
            this.btn_K.Size = new System.Drawing.Size(32, 32);
            this.btn_K.TabIndex = 9;
            this.btn_K.Text = "K";
            this.btn_K.UseVisualStyleBackColor = false;
            this.btn_K.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_I
            // 
            this.btn_I.BackColor = System.Drawing.Color.White;
            this.btn_I.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_I.Location = new System.Drawing.Point(315, 15);
            this.btn_I.Name = "btn_I";
            this.btn_I.Size = new System.Drawing.Size(32, 32);
            this.btn_I.TabIndex = 8;
            this.btn_I.Text = "I";
            this.btn_I.UseVisualStyleBackColor = false;
            this.btn_I.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_H
            // 
            this.btn_H.BackColor = System.Drawing.Color.White;
            this.btn_H.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_H.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_H.Location = new System.Drawing.Point(277, 15);
            this.btn_H.Name = "btn_H";
            this.btn_H.Size = new System.Drawing.Size(32, 32);
            this.btn_H.TabIndex = 7;
            this.btn_H.Text = "H";
            this.btn_H.UseVisualStyleBackColor = false;
            this.btn_H.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_G
            // 
            this.btn_G.BackColor = System.Drawing.Color.White;
            this.btn_G.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_G.Location = new System.Drawing.Point(239, 15);
            this.btn_G.Name = "btn_G";
            this.btn_G.Size = new System.Drawing.Size(32, 32);
            this.btn_G.TabIndex = 6;
            this.btn_G.Text = "G";
            this.btn_G.UseVisualStyleBackColor = false;
            this.btn_G.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_F
            // 
            this.btn_F.BackColor = System.Drawing.Color.White;
            this.btn_F.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_F.Location = new System.Drawing.Point(201, 15);
            this.btn_F.Name = "btn_F";
            this.btn_F.Size = new System.Drawing.Size(32, 32);
            this.btn_F.TabIndex = 5;
            this.btn_F.Text = "F";
            this.btn_F.UseVisualStyleBackColor = false;
            this.btn_F.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_E
            // 
            this.btn_E.BackColor = System.Drawing.Color.White;
            this.btn_E.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_E.Location = new System.Drawing.Point(163, 15);
            this.btn_E.Name = "btn_E";
            this.btn_E.Size = new System.Drawing.Size(32, 32);
            this.btn_E.TabIndex = 4;
            this.btn_E.Text = "E";
            this.btn_E.UseVisualStyleBackColor = false;
            this.btn_E.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_D
            // 
            this.btn_D.BackColor = System.Drawing.Color.White;
            this.btn_D.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_D.Location = new System.Drawing.Point(125, 15);
            this.btn_D.Name = "btn_D";
            this.btn_D.Size = new System.Drawing.Size(32, 32);
            this.btn_D.TabIndex = 3;
            this.btn_D.Text = "D";
            this.btn_D.UseVisualStyleBackColor = false;
            this.btn_D.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_C
            // 
            this.btn_C.BackColor = System.Drawing.Color.White;
            this.btn_C.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_C.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_C.Location = new System.Drawing.Point(87, 15);
            this.btn_C.Name = "btn_C";
            this.btn_C.Size = new System.Drawing.Size(32, 32);
            this.btn_C.TabIndex = 2;
            this.btn_C.Text = "C";
            this.btn_C.UseVisualStyleBackColor = false;
            this.btn_C.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_B
            // 
            this.btn_B.BackColor = System.Drawing.Color.White;
            this.btn_B.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_B.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_B.Location = new System.Drawing.Point(49, 15);
            this.btn_B.Name = "btn_B";
            this.btn_B.Size = new System.Drawing.Size(32, 32);
            this.btn_B.TabIndex = 1;
            this.btn_B.Text = "B";
            this.btn_B.UseVisualStyleBackColor = false;
            this.btn_B.Click += new System.EventHandler(this.gerarLetras);
            // 
            // btn_A
            // 
            this.btn_A.BackColor = System.Drawing.Color.White;
            this.btn_A.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_A.Location = new System.Drawing.Point(11, 15);
            this.btn_A.Name = "btn_A";
            this.btn_A.Size = new System.Drawing.Size(32, 32);
            this.btn_A.TabIndex = 0;
            this.btn_A.Text = "A";
            this.btn_A.UseVisualStyleBackColor = false;
            this.btn_A.Click += new System.EventHandler(this.gerarLetras);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(579, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(84, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Erros";
            // 
            // lb_erro
            // 
            this.lb_erro.AutoSize = true;
            this.lb_erro.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_erro.Location = new System.Drawing.Point(586, 82);
            this.lb_erro.Name = "lb_erro";
            this.lb_erro.Size = new System.Drawing.Size(30, 31);
            this.lb_erro.TabIndex = 3;
            this.lb_erro.Text = "?";
            // 
            // btn_Cadastrar
            // 
            this.btn_Cadastrar.BackColor = System.Drawing.Color.White;
            this.btn_Cadastrar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Cadastrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Cadastrar.Location = new System.Drawing.Point(686, 33);
            this.btn_Cadastrar.Name = "btn_Cadastrar";
            this.btn_Cadastrar.Size = new System.Drawing.Size(175, 47);
            this.btn_Cadastrar.TabIndex = 4;
            this.btn_Cadastrar.Text = "Cadastrar";
            this.btn_Cadastrar.UseVisualStyleBackColor = false;
            // 
            // btn_Iniciar
            // 
            this.btn_Iniciar.BackColor = System.Drawing.Color.White;
            this.btn_Iniciar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Iniciar.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Iniciar.Location = new System.Drawing.Point(686, 87);
            this.btn_Iniciar.Name = "btn_Iniciar";
            this.btn_Iniciar.Size = new System.Drawing.Size(85, 45);
            this.btn_Iniciar.TabIndex = 5;
            this.btn_Iniciar.Text = "Iniciar";
            this.btn_Iniciar.UseVisualStyleBackColor = false;
            this.btn_Iniciar.Click += new System.EventHandler(this.btn_Iniciar_Click);
            // 
            // btn_Dica
            // 
            this.btn_Dica.BackColor = System.Drawing.Color.White;
            this.btn_Dica.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_Dica.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Dica.Location = new System.Drawing.Point(776, 86);
            this.btn_Dica.Name = "btn_Dica";
            this.btn_Dica.Size = new System.Drawing.Size(85, 45);
            this.btn_Dica.TabIndex = 6;
            this.btn_Dica.Text = "Dica";
            this.btn_Dica.UseVisualStyleBackColor = false;
            this.btn_Dica.Click += new System.EventHandler(this.btn_Dica_Click);
            // 
            // txt_Letras
            // 
            this.txt_Letras.BackColor = System.Drawing.Color.White;
            this.txt_Letras.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Letras.Location = new System.Drawing.Point(583, 194);
            this.txt_Letras.Name = "txt_Letras";
            this.txt_Letras.Size = new System.Drawing.Size(278, 31);
            this.txt_Letras.TabIndex = 7;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(577, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(206, 31);
            this.label2.TabIndex = 8;
            this.label2.Text = "Letras jogadas";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(577, 238);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(264, 31);
            this.label3.TabIndex = 9;
            this.label3.Text = "Palavra a adivinhar";
            // 
            // txt_Palavra
            // 
            this.txt_Palavra.BackColor = System.Drawing.Color.White;
            this.txt_Palavra.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_Palavra.Location = new System.Drawing.Point(583, 272);
            this.txt_Palavra.Name = "txt_Palavra";
            this.txt_Palavra.Size = new System.Drawing.Size(278, 31);
            this.txt_Palavra.TabIndex = 10;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(669, 340);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(114, 25);
            this.label4.TabIndex = 11;
            this.label4.Text = "Categoria";
            // 
            // rb_Animais
            // 
            this.rb_Animais.AutoSize = true;
            this.rb_Animais.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Animais.Location = new System.Drawing.Point(7, 28);
            this.rb_Animais.Name = "rb_Animais";
            this.rb_Animais.Size = new System.Drawing.Size(90, 24);
            this.rb_Animais.TabIndex = 12;
            this.rb_Animais.TabStop = true;
            this.rb_Animais.Text = "Animais";
            this.rb_Animais.UseVisualStyleBackColor = true;
            // 
            // rb_cidades
            // 
            this.rb_cidades.AutoSize = true;
            this.rb_cidades.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_cidades.Location = new System.Drawing.Point(104, 28);
            this.rb_cidades.Name = "rb_cidades";
            this.rb_cidades.Size = new System.Drawing.Size(83, 24);
            this.rb_cidades.TabIndex = 13;
            this.rb_cidades.TabStop = true;
            this.rb_cidades.Text = "Cidade";
            this.rb_cidades.UseVisualStyleBackColor = true;
            // 
            // rb_Times
            // 
            this.rb_Times.AutoSize = true;
            this.rb_Times.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Times.Location = new System.Drawing.Point(195, 28);
            this.rb_Times.Name = "rb_Times";
            this.rb_Times.Size = new System.Drawing.Size(74, 24);
            this.rb_Times.TabIndex = 14;
            this.rb_Times.TabStop = true;
            this.rb_Times.Text = "Times";
            this.rb_Times.UseVisualStyleBackColor = true;
            // 
            // rb_Objetos
            // 
            this.rb_Objetos.AutoSize = true;
            this.rb_Objetos.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Objetos.Location = new System.Drawing.Point(7, 58);
            this.rb_Objetos.Name = "rb_Objetos";
            this.rb_Objetos.Size = new System.Drawing.Size(89, 24);
            this.rb_Objetos.TabIndex = 15;
            this.rb_Objetos.TabStop = true;
            this.rb_Objetos.Text = "Objetos";
            this.rb_Objetos.UseVisualStyleBackColor = true;
            // 
            // rb_Frutas
            // 
            this.rb_Frutas.AutoSize = true;
            this.rb_Frutas.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Frutas.Location = new System.Drawing.Point(104, 58);
            this.rb_Frutas.Name = "rb_Frutas";
            this.rb_Frutas.Size = new System.Drawing.Size(79, 24);
            this.rb_Frutas.TabIndex = 16;
            this.rb_Frutas.TabStop = true;
            this.rb_Frutas.Text = "Frutas";
            this.rb_Frutas.UseVisualStyleBackColor = true;
            // 
            // rb_Carros
            // 
            this.rb_Carros.AutoSize = true;
            this.rb_Carros.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Carros.Location = new System.Drawing.Point(195, 58);
            this.rb_Carros.Name = "rb_Carros";
            this.rb_Carros.Size = new System.Drawing.Size(80, 24);
            this.rb_Carros.TabIndex = 17;
            this.rb_Carros.TabStop = true;
            this.rb_Carros.Text = "Carros";
            this.rb_Carros.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(104, 8);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(65, 25);
            this.label5.TabIndex = 18;
            this.label5.Text = "Nível";
            // 
            // rb_Facil
            // 
            this.rb_Facil.AutoSize = true;
            this.rb_Facil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Facil.Location = new System.Drawing.Point(13, 49);
            this.rb_Facil.Name = "rb_Facil";
            this.rb_Facil.Size = new System.Drawing.Size(65, 24);
            this.rb_Facil.TabIndex = 19;
            this.rb_Facil.TabStop = true;
            this.rb_Facil.Text = "Fácil";
            this.rb_Facil.UseVisualStyleBackColor = true;
            // 
            // rb_Medio
            // 
            this.rb_Medio.AutoSize = true;
            this.rb_Medio.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Medio.Location = new System.Drawing.Point(103, 49);
            this.rb_Medio.Name = "rb_Medio";
            this.rb_Medio.Size = new System.Drawing.Size(75, 24);
            this.rb_Medio.TabIndex = 20;
            this.rb_Medio.TabStop = true;
            this.rb_Medio.Text = "Médio";
            this.rb_Medio.UseVisualStyleBackColor = true;
            // 
            // rb_Dificil
            // 
            this.rb_Dificil.AutoSize = true;
            this.rb_Dificil.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rb_Dificil.Location = new System.Drawing.Point(199, 49);
            this.rb_Dificil.Name = "rb_Dificil";
            this.rb_Dificil.Size = new System.Drawing.Size(71, 24);
            this.rb_Dificil.TabIndex = 21;
            this.rb_Dificil.TabStop = true;
            this.rb_Dificil.Text = "Difícil";
            this.rb_Dificil.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.White;
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.rb_Times);
            this.panel2.Controls.Add(this.rb_Carros);
            this.panel2.Controls.Add(this.rb_Animais);
            this.panel2.Controls.Add(this.rb_Objetos);
            this.panel2.Controls.Add(this.rb_Frutas);
            this.panel2.Controls.Add(this.rb_cidades);
            this.panel2.Location = new System.Drawing.Point(583, 336);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(278, 100);
            this.panel2.TabIndex = 22;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.White;
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.rb_Dificil);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Controls.Add(this.rb_Medio);
            this.panel3.Controls.Add(this.rb_Facil);
            this.panel3.Location = new System.Drawing.Point(583, 442);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(276, 85);
            this.panel3.TabIndex = 23;
            // 
            // lb_Chances
            // 
            this.lb_Chances.AutoSize = true;
            this.lb_Chances.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_Chances.Location = new System.Drawing.Point(626, 81);
            this.lb_Chances.Name = "lb_Chances";
            this.lb_Chances.Size = new System.Drawing.Size(30, 31);
            this.lb_Chances.TabIndex = 24;
            this.lb_Chances.Text = "?";
            // 
            // lb_barras
            // 
            this.lb_barras.AutoSize = true;
            this.lb_barras.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_barras.Location = new System.Drawing.Point(610, 81);
            this.lb_barras.Name = "lb_barras";
            this.lb_barras.Size = new System.Drawing.Size(23, 31);
            this.lb_barras.TabIndex = 25;
            this.lb_barras.Text = "/";
            // 
            // pbImagens
            // 
            this.pbImagens.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbImagens.Image = global::Jogo_da_Forca.Properties.Resources.facil_sem_cbeça;
            this.pbImagens.Location = new System.Drawing.Point(38, 160);
            this.pbImagens.Name = "pbImagens";
            this.pbImagens.Size = new System.Drawing.Size(512, 367);
            this.pbImagens.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbImagens.TabIndex = 0;
            this.pbImagens.TabStop = false;
            // 
            // Tela_Principal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(884, 561);
            this.Controls.Add(this.lb_Chances);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txt_Palavra);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txt_Letras);
            this.Controls.Add(this.btn_Dica);
            this.Controls.Add(this.btn_Iniciar);
            this.Controls.Add(this.btn_Cadastrar);
            this.Controls.Add(this.lb_erro);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pbImagens);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.lb_barras);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Tela_Principal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Jogo da Forca";
            this.Load += new System.EventHandler(this.Tela_Principal_Load);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbImagens)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.PictureBox pbImagens;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_Z;
        private System.Windows.Forms.Button btn_Y;
        private System.Windows.Forms.Button btn_W;
        private System.Windows.Forms.Button btn_X;
        private System.Windows.Forms.Button btn_V;
        private System.Windows.Forms.Button btn_U;
        private System.Windows.Forms.Button btn_T;
        private System.Windows.Forms.Button btn_S;
        private System.Windows.Forms.Button btn_R;
        private System.Windows.Forms.Button btn_Q;
        private System.Windows.Forms.Button btn_P;
        private System.Windows.Forms.Button btn_O;
        private System.Windows.Forms.Button btn_N;
        private System.Windows.Forms.Button btn_M;
        private System.Windows.Forms.Button btn_L;
        private System.Windows.Forms.Button btn_J;
        private System.Windows.Forms.Button btn_K;
        private System.Windows.Forms.Button btn_I;
        private System.Windows.Forms.Button btn_H;
        private System.Windows.Forms.Button btn_G;
        private System.Windows.Forms.Button btn_F;
        private System.Windows.Forms.Button btn_E;
        private System.Windows.Forms.Button btn_D;
        private System.Windows.Forms.Button btn_C;
        private System.Windows.Forms.Button btn_B;
        private System.Windows.Forms.Button btn_A;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lb_erro;
        private System.Windows.Forms.Button btn_Cadastrar;
        private System.Windows.Forms.Button btn_Iniciar;
        private System.Windows.Forms.Button btn_Dica;
        private System.Windows.Forms.TextBox txt_Letras;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txt_Palavra;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rb_Animais;
        private System.Windows.Forms.RadioButton rb_cidades;
        private System.Windows.Forms.RadioButton rb_Times;
        private System.Windows.Forms.RadioButton rb_Objetos;
        private System.Windows.Forms.RadioButton rb_Frutas;
        private System.Windows.Forms.RadioButton rb_Carros;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.RadioButton rb_Facil;
        private System.Windows.Forms.RadioButton rb_Medio;
        private System.Windows.Forms.RadioButton rb_Dificil;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label lb_Chances;
        private System.Windows.Forms.Label lb_barras;
    }
}

